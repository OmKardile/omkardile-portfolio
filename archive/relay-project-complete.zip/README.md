# Relay — UX Case Study

A trust-first agentic AI assistant for life admin. Mobile app concept, exploratory UX project built end-to-end: trend research → persona → information architecture → interaction flow → visual system → prototype → case study.

## What's in here

- **`relay-case-study.docx`** — the full write-up: 2026 trend research, competitive landscape, persona, problem statement, information architecture, the checkpoint interaction flow, visual design system, and all four key screens.
- **`relay-prototype.jsx`** — a working, clickable React prototype (not static mockups). Covers the full loop: delegate a task, watch it move to a checkpoint after a short research delay, approve or decline, and adjust per-category autonomy in settings.
- **`screens/`** — the four key screens (Home, Checkpoint, Delegate, Activity & Settings) as standalone PNGs, sized for portfolio use.
- **`diagrams/`** — the information architecture map, the checkpoint flow diagram, and the color palette reference.
- **`showcase/`** — a ready-to-post Dribbble-style cover shot (all three signature screens in one banner).

## The core idea

Relay delegates errands — cancelling a forgotten subscription, disputing a late fee, negotiating a bill, tracking a price — to an AI agent. The design thesis: full AI autonomy feels invasive the first time it surprises you; full manual review defeats the point of delegating in the first place. So Relay never acts past a decision point without presenting the options and waiting for an explicit yes. That pause is the **checkpoint** — the one interaction the whole app is built to protect.

## Visual design system

| Token | Hex | Use |
|---|---|---|
| Mist | `#F0F3F0` | Background |
| Pine | `#0F6E56` | Primary / brand |
| Ink | `#1C2624` | Text |
| Moss | `#62726B` | Secondary text |
| Gold border | `#D9A84E` | Checkpoint accent |
| Gold text | `#7A5518` | Checkpoint text |

Gold is reserved exclusively for checkpoint/approval moments and appears nowhere else — the quiet-by-default, loud-only-when-it-matters logic is the whole point.

## Running the prototype

Easiest path: paste `relay-prototype.jsx` into a CodeSandbox or StackBlitz React template and add `lucide-react` as a dependency. It's a single self-contained component (default export, `useState` only) — no other setup required.

## Credits

Font: Liberation Sans (metric-compatible with Arial). Icons: Lucide. All copy, data, and the Maya persona are fictional, created for this exercise.
