# Taar — Fashion E-commerce App Redesign (Project 1)

Mobile-first product discovery UI for a fictional label, "Taar". Case-study focus: **fewer taps to narrow a catalogue**, with availability and price clarity up front.

## Run
```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build -> dist/
```
Deploy: push to GitHub, import in Vercel (framework: Vite). No config needed.

## Structure
```
src/
  App.jsx                 state: category, filters, sort, bag
  styles.css              tokens + all styles
  data/products.js        catalogue, sizes, colours, price helper
  components/
    Sheet.jsx             bottom-sheet base (Esc, scrim, scroll lock, inert)
    FilterSheet.jsx       size / colour / price, live result count
    QuickAdd.jsx          colour + size pick, sold-out sizes disabled
    ProductCard.jsx       tonal image slot, price, colour dots
```

## UX decisions (interview talking points)
- Filter is one bottom sheet, results update live, CTA shows the count ("Show 4 pieces").
- Active filters stay visible as removable chips under the bar.
- Sold-out sizes are shown and struck through, not hidden.
- Quick add from the grid: pick size, add, done — no page change.
- 44px minimum touch targets, visible focus, reduced-motion respected.
- Don't quote tap-count or conversion numbers in the case study until you've measured the original app yourself.

## Swapping in photography
Add images to `public/images/` and set `image: '/images/linen-overshirt.jpg'` on a product. Real, art-directed shots only.

## Next
- [ ] Figma file (research, flows, wireframes, hi-fi) matching these screens
- [ ] Framer prototype of the filter + quick-add flow
- [ ] Product detail + bag screens
- [ ] Deploy to Vercel, add link to portfolio

---
Designed & developed by [Omkar Kardile](https://omkardile.is-a.dev/)
