# Changelog

## 0.1.0
- Initial build: product listing, category tabs, sort
- Filter bottom sheet (size, colour, price) with live count and removable chips
- Quick-add sheet with sold-out size states
- Editorial type (Fraunces + Hanken Grotesk), warm-paper palette, navy accent
- Tonal image slots ready for real photography
