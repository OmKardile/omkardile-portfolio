import { useMemo, useState } from 'react';
import { ShoppingBag, SlidersHorizontal, X } from 'lucide-react';
import { PRODUCTS, CATEGORIES, MAX_PRICE, inr } from './data/products';
import ProductCard from './components/ProductCard';
import FilterSheet from './components/FilterSheet';
import QuickAdd from './components/QuickAdd';

const BASE = { sizes: [], colors: [], max: MAX_PRICE };

export default function App() {
  const [cat, setCat] = useState('All');
  const [filters, setFilters] = useState(BASE);
  const [sort, setSort] = useState('featured');
  const [filterOpen, setFilterOpen] = useState(false);
  const [quick, setQuick] = useState(null);
  const [bag, setBag] = useState(0);

  const items = useMemo(() => {
    const list = PRODUCTS.filter((p) =>
      (cat === 'All' || p.category === cat) &&
      p.price <= filters.max &&
      (!filters.sizes.length || filters.sizes.some((s) => p.sizes.includes(s))) &&
      (!filters.colors.length || filters.colors.some((c) => p.colors.includes(c))));
    if (sort === 'low') return [...list].sort((a, b) => a.price - b.price);
    if (sort === 'high') return [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [cat, filters, sort]);

  const chips = [
    ...filters.sizes.map((v) => ({ k: 'sizes', v, label: `Size ${v}` })),
    ...filters.colors.map((v) => ({ k: 'colors', v, label: v })),
    ...(filters.max < MAX_PRICE ? [{ k: 'max', label: `Under ${inr(filters.max)}` }] : []),
  ];
  const removeChip = (c) =>
    setFilters((f) => (c.k === 'max' ? { ...f, max: MAX_PRICE } : { ...f, [c.k]: f[c.k].filter((x) => x !== c.v) }));

  return (
    <div className="app">
      <header className="top">
        <span className="mark">Taar</span>
        <button className="bag" aria-label={`Bag, ${bag} items`}><ShoppingBag size={20} /><b>{bag}</b></button>
      </header>

      <section className="hero">
        <small>Autumn 2026</small>
        <h1>The Autumn <em>Edit</em></h1>
        <p>Ten pieces, cut for Pune’s cooler mornings.</p>
      </section>

      <div className="bar">
        <nav className="tabs" aria-label="Categories">
          {CATEGORIES.map((c) => (
            <button key={c} className="tab" aria-pressed={cat === c} onClick={() => setCat(c)}>{c}</button>
          ))}
        </nav>
        <div className="tools">
          <button className="filterbtn" onClick={() => setFilterOpen(true)}>
            <SlidersHorizontal size={18} /> Filter{chips.length ? ` (${chips.length})` : ''}
          </button>
          <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort">
            <option value="featured">Featured</option>
            <option value="low">Price: low to high</option>
            <option value="high">Price: high to low</option>
          </select>
        </div>
        {chips.length > 0 && (
          <div className="chips">
            {chips.map((c) => (
              <button key={c.k + (c.v || '')} className="chip" onClick={() => removeChip(c)} aria-label={`Remove ${c.label}`}>
                {c.label} <X size={14} />
              </button>
            ))}
          </div>
        )}
      </div>

      <main className="grid">
        {items.map((p, i) => <ProductCard key={p.id} p={p} i={i} onQuickAdd={setQuick} />)}
        {!items.length && (
          <div className="empty">
            <h2>Nothing fits that combination.</h2>
            <p>Try a wider price range or fewer colours.</p>
            <button className="cta" onClick={() => { setFilters(BASE); setCat('All'); }}>Clear everything</button>
          </div>
        )}
      </main>

      <footer className="foot">
        <a href="https://omkardile.is-a.dev/" target="_blank" rel="noreferrer">Designed &amp; developed by Omkar Kardile</a>
      </footer>

      <FilterSheet open={filterOpen} onClose={() => setFilterOpen(false)} filters={filters} setFilters={setFilters} count={items.length} />
      <QuickAdd product={quick} onClose={() => setQuick(null)} onAdd={() => { setBag((b) => b + 1); setQuick(null); }} />
    </div>
  );
}
