// `sizes` = sizes currently in stock. Anything in SIZES but not listed is sold out.
// Drop real photography into public/images and set `image` on a product to replace the tonal slot.
export const SIZES = ['S', 'M', 'L', 'XL'];
export const COLORS = {
  Sand: '#D9CBB0', Olive: '#6B6B4A', Charcoal: '#33363B', Navy: '#1F2A44',
  White: '#F2EFE8', Oat: '#CFC3AE', Sky: '#AFC3D6',
};
export const CATEGORIES = ['All', 'Shirts', 'Trousers', 'Knitwear', 'Outerwear', 'Essentials'];
export const MAX_PRICE = 12000;

export const inr = (n) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

export const PRODUCTS = [
  { id: 1, name: 'Linen Overshirt', category: 'Shirts', price: 3490, colors: ['Sand', 'Olive'], sizes: ['S', 'M', 'L', 'XL'], tone: '#E4DACA' },
  { id: 2, name: 'Wool Blend Trouser', category: 'Trousers', price: 4290, colors: ['Charcoal', 'Navy'], sizes: ['M', 'L'], tone: '#D8D6D2' },
  { id: 3, name: 'Oxford Shirt', category: 'Shirts', price: 2790, colors: ['White', 'Sky'], sizes: ['S', 'M', 'L'], tone: '#E9E6DE' },
  { id: 4, name: 'Merino Crew', category: 'Knitwear', price: 4990, colors: ['Navy', 'Oat'], sizes: ['S', 'L', 'XL'], tone: '#D5D9E0' },
  { id: 5, name: 'Chore Jacket', category: 'Outerwear', price: 6490, colors: ['Olive', 'Charcoal'], sizes: ['M', 'L', 'XL'], tone: '#D9D8CB' },
  { id: 6, name: 'Pleated Chino', category: 'Trousers', price: 3290, colors: ['Sand', 'Navy'], sizes: ['S', 'M', 'L', 'XL'], tone: '#E6DCC9' },
  { id: 7, name: 'Heavyweight Tee', category: 'Essentials', price: 1290, colors: ['White', 'Charcoal'], sizes: ['S', 'M', 'L', 'XL'], tone: '#ECE9E2' },
  { id: 8, name: 'Cable Cardigan', category: 'Knitwear', price: 5490, colors: ['Oat', 'Charcoal'], sizes: ['M', 'L'], tone: '#E3DBCB' },
  { id: 9, name: 'Wool Overcoat', category: 'Outerwear', price: 11990, colors: ['Charcoal', 'Navy'], sizes: ['M', 'L', 'XL'], tone: '#CFD0D3' },
  { id: 10, name: 'Camp Collar Shirt', category: 'Shirts', price: 2990, colors: ['Sand', 'Olive'], sizes: ['S', 'M', 'XL'], tone: '#E1D8C4' },
];
