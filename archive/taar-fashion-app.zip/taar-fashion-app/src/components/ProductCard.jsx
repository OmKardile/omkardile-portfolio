import { Plus } from 'lucide-react';
import { COLORS, inr } from '../data/products';

export default function ProductCard({ p, i, onQuickAdd }) {
  return (
    <article className="card" style={{ '--i': i }}>
      <div className="ph" style={{ '--tone': p.tone }}>
        {p.image ? <img src={p.image} alt={p.name} loading="lazy" /> : <i>{p.category}</i>}
        <button className="qa" onClick={() => onQuickAdd(p)} aria-label={`Quick add ${p.name}`}><Plus size={20} /></button>
      </div>
      <h3>{p.name}</h3>
      <p className="row">
        <span>{inr(p.price)}</span>
        <span className="dots">{p.colors.map((c) => <span key={c} className="dot" title={c} style={{ background: COLORS[c] }} />)}</span>
      </p>
    </article>
  );
}
