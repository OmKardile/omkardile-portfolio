import { useState } from 'react';
import Sheet from './Sheet';
import { SIZES, COLORS, inr } from '../data/products';

function Body({ p, onAdd }) {
  const [size, setSize] = useState(null);
  const [color, setColor] = useState(p.colors[0]);
  return (
    <>
      <p className="meta">{p.category} · {inr(p.price)}</p>
      <div className="grp">
        <h3>Colour — {color}</h3>
        <div className="opts">
          {p.colors.map((c) => (
            <button key={c} className="opt" aria-pressed={color === c} onClick={() => setColor(c)}>
              <span className="dot" style={{ background: COLORS[c] }} />{c}
            </button>
          ))}
        </div>
      </div>
      <div className="grp">
        <h3>Size</h3>
        <div className="opts">
          {SIZES.map((s) => {
            const out = !p.sizes.includes(s);
            return (
              <button key={s} className="opt" disabled={out} aria-pressed={size === s}
                aria-label={out ? `${s}, sold out` : s} onClick={() => setSize(s)}>{s}</button>
            );
          })}
        </div>
      </div>
      <button className="cta" disabled={!size} onClick={() => onAdd({ size, color })}>
        {size ? `Add to bag — ${inr(p.price)}` : 'Select a size'}
      </button>
    </>
  );
}

export default function QuickAdd({ product, onClose, onAdd }) {
  return (
    <Sheet open={!!product} onClose={onClose} title={product ? product.name : ''}>
      {product && <Body key={product.id} p={product} onAdd={onAdd} />}
    </Sheet>
  );
}
