import Sheet from './Sheet';
import { SIZES, COLORS, MAX_PRICE, inr } from '../data/products';

export default function FilterSheet({ open, onClose, filters, setFilters, count }) {
  const toggle = (key, v) =>
    setFilters((f) => ({ ...f, [key]: f[key].includes(v) ? f[key].filter((x) => x !== v) : [...f[key], v] }));

  return (
    <Sheet open={open} onClose={onClose} title="Filter">
      <div className="grp">
        <h3>Size</h3>
        <div className="opts">
          {SIZES.map((s) => (
            <button key={s} className="opt" aria-pressed={filters.sizes.includes(s)} onClick={() => toggle('sizes', s)}>{s}</button>
          ))}
        </div>
      </div>
      <div className="grp">
        <h3>Colour</h3>
        <div className="opts">
          {Object.entries(COLORS).map(([name, hex]) => (
            <button key={name} className="opt" aria-pressed={filters.colors.includes(name)} onClick={() => toggle('colors', name)}>
              <span className="dot" style={{ background: hex }} />{name}
            </button>
          ))}
        </div>
      </div>
      <div className="grp">
        <h3>Price up to {inr(filters.max)}</h3>
        <input
          type="range" min="1000" max={MAX_PRICE} step="500" value={filters.max}
          aria-label="Maximum price" onChange={(e) => setFilters((f) => ({ ...f, max: +e.target.value }))}
        />
      </div>
      <button className="cta" onClick={onClose}>
        {count ? `Show ${count} ${count === 1 ? 'piece' : 'pieces'}` : 'No pieces match'}
      </button>
    </Sheet>
  );
}
