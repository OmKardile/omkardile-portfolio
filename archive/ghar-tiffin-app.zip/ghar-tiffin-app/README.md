# Ghar — Pune Tiffin App (Project 2)

Mobile-first app for finding, subscribing to and tracking home-cooked tiffin services around Pimpri-Chinchwad. Case-study focus: a **three-step order flow** and **skip-a-day in one tap**.

## Run
```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build -> dist/
```
Deploy: push to GitHub, import in Vercel (framework: Vite).

## Structure
```
src/
  App.jsx                 screen state + tab bar
  styles.css              tokens + styles
  data/providers.js       mock kitchens, areas, diets, helpers
  screens/
    Home.jsx              area + diet filters, kitchen list
    Provider.jsx          step 1 of 3: menu + cutoff
    Order.jsx             step 2 (plan) and 3 (confirm, UPI mock)
    Today.jsx             delivery tracker + skip tomorrow
```

## UX decisions (interview talking points)
- Kitchens are a list, not cards: menu, price and cutoff time scan in one glance.
- Diet (Veg / Jain / Non-veg / High protein) is a first-level filter, not buried.
- Cutoff time is shown on every row because it decides whether you can order today.
- The plan builder shows the weekly price live as you change meals and days.
- Skip tomorrow is a first-class action on Today, with the credit stated up front.
- Everything uses 44px targets, visible focus, reduced-motion support.

## Honest limits
- Data is mock; payment and delivery status are simulated.
- Skipping needs a provider-side view to be real. That's the next design problem.
- Validate every assumption with real customers and kitchens before quoting anything in the case study.

## Next
- [ ] Figma file matching these screens
- [ ] Framer prototype of the 3-step flow + skip
- [ ] Provider-side dashboard concept
- [ ] Deploy to Vercel, link from portfolio

---
Designed & developed by [Omkar Kardile](https://omkardile.is-a.dev/)
