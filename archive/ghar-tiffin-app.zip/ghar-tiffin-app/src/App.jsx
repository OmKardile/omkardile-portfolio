import { useState } from 'react';
import { Compass, CalendarCheck } from 'lucide-react';
import Home from './screens/Home';
import Provider from './screens/Provider';
import Order from './screens/Order';
import Today from './screens/Today';

export default function App() {
  const [screen, setScreen] = useState('home');
  const [provider, setProvider] = useState(null);
  const [order, setOrder] = useState(null);

  const showTabs = screen === 'home' || screen === 'today';
  return (
    <div className="app">
      <main>
        {screen === 'home' && <Home onOpen={(p) => { setProvider(p); setScreen('provider'); }} />}
        {screen === 'provider' && <Provider p={provider} onBack={() => setScreen('home')} onNext={() => setScreen('order')} />}
        {screen === 'order' && <Order p={provider} onBack={() => setScreen('provider')} onDone={(o) => { setOrder(o); setScreen('today'); }} />}
        {screen === 'today' && <Today order={order} onFind={() => setScreen('home')} />}
      </main>
      <footer className="foot">
        <a href="https://omkardile.is-a.dev/" target="_blank" rel="noreferrer">Designed &amp; developed by Omkar Kardile</a>
      </footer>
      {showTabs && (
        <nav className="tabbar" aria-label="Main">
          <button aria-current={screen === 'home'} onClick={() => setScreen('home')}><Compass size={20} />Discover</button>
          <button aria-current={screen === 'today'} onClick={() => setScreen('today')}><CalendarCheck size={20} />Today</button>
        </nav>
      )}
    </div>
  );
}
