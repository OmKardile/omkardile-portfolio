// Mock data. Replace with real providers once you have interview partners.
export const AREAS = ['All areas', 'Pimpri', 'Chinchwad', 'Akurdi', 'Nigdi'];
export const DIETS = ['Veg', 'Jain', 'Non-veg', 'High protein'];
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const SLOTS = ['Lunch', 'Dinner'];

export const inr = (n) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

export const PROVIDERS = [
  { id: 1, name: 'Aai’s Tiffin', area: 'Chinchwad', diets: ['Veg'], perMeal: 80, cutoff: '9:00 am',
    menu: { Lunch: 'Varan bhaat, bhaji, 3 chapatis, koshimbir', Dinner: 'Pithla, bhakri, rice, thecha' } },
  { id: 2, name: 'Annapurna Jain Kitchen', area: 'Pimpri', diets: ['Veg', 'Jain'], perMeal: 90, cutoff: '8:30 am',
    menu: { Lunch: 'Dal, paneer bhurji, 4 phulkas, rice', Dinner: 'Moong khichdi, kadhi, papad' } },
  { id: 3, name: 'Sakhi Home Meals', area: 'Akurdi', diets: ['Veg'], perMeal: 70, cutoff: '9:30 am',
    menu: { Lunch: 'Usal, chapati, rice, salad', Dinner: 'Aloo gobhi, dal tadka, chapati' } },
  { id: 4, name: 'Protein Box Pune', area: 'Nigdi', diets: ['Non-veg', 'High protein'], perMeal: 130, cutoff: '8:00 am',
    menu: { Lunch: 'Chicken curry, brown rice, sprouts', Dinner: 'Egg bhurji, 2 rotis, dal' } },
  { id: 5, name: 'Gharcha Swad', area: 'Chinchwad', diets: ['Veg', 'Jain'], perMeal: 85, cutoff: '9:00 am',
    menu: { Lunch: 'Dal fry, jeera rice, bhaji, 3 chapatis', Dinner: 'Matki usal, bhakri, rice' } },
  { id: 6, name: 'Thali House', area: 'Pimpri', diets: ['Veg', 'Non-veg'], perMeal: 110, cutoff: '9:00 am',
    menu: { Lunch: 'Mutton or paneer thali, rice, solkadhi', Dinner: 'Fish or veg thali, rice, sol kadhi' } },
];
