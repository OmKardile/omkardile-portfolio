import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { PROVIDERS, AREAS, DIETS, inr } from '../data/providers';

export default function Home({ onOpen }) {
  const [area, setArea] = useState('All areas');
  const [diet, setDiet] = useState(null);
  const list = PROVIDERS.filter((p) => (area === 'All areas' || p.area === area) && (!diet || p.diets.includes(diet)));

  return (
    <>
      <header className="hero">
        <small>Pimpri-Chinchwad</small>
        <h1>Home-cooked, <em>every day.</em></h1>
        <label className="area">
          <span>Near</span>
          <select value={area} onChange={(e) => setArea(e.target.value)} aria-label="Area">
            {AREAS.map((a) => <option key={a}>{a}</option>)}
          </select>
        </label>
      </header>
      <div className="chips" role="group" aria-label="Diet">
        {DIETS.map((d) => (
          <button key={d} className="opt" aria-pressed={diet === d} onClick={() => setDiet(diet === d ? null : d)}>{d}</button>
        ))}
      </div>
      <ul className="rows">
        {list.map((p) => (
          <li key={p.id}>
            <button className="prow" onClick={() => onOpen(p)}>
              <div>
                <h2>{p.name}</h2>
                <p className="mute">{p.area} · {p.diets.join(', ')}</p>
                <p className="menu">{p.menu.Lunch}</p>
                <p className="mute small">Order before {p.cutoff} for same-day lunch</p>
              </div>
              <div className="price"><b>{inr(p.perMeal)}</b><span>per meal</span><ChevronRight size={18} /></div>
            </button>
          </li>
        ))}
        {!list.length && <li className="empty"><h2>No tiffin matches yet.</h2><p>Try another area or remove the diet filter.</p></li>}
      </ul>
    </>
  );
}
