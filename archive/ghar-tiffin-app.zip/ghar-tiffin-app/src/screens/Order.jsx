import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { DAYS, SLOTS, inr } from '../data/providers';

export default function Order({ p, onBack, onDone }) {
  const [step, setStep] = useState('plan');
  const [slots, setSlots] = useState(['Lunch']);
  const [days, setDays] = useState(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
  const [start, setStart] = useState('Tomorrow');

  const toggle = (list, set, v) => set(list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  const weekly = p.perMeal * slots.length * days.length;
  const valid = slots.length > 0 && days.length > 0;

  return (
    <section className="page">
      <button className="back" onClick={step === 'plan' ? onBack : () => setStep('plan')}><ArrowLeft size={20} /> Back</button>
      <p className="step">Step {step === 'plan' ? 2 : 3} of 3 · {step === 'plan' ? 'Plan' : 'Confirm'}</p>
      <h1 className="title">{step === 'plan' ? 'Build your week' : 'Confirm & pay'}</h1>

      {step === 'plan' ? (
        <>
          <div className="grp"><h3>Meals</h3><div className="opts">
            {SLOTS.map((s) => <button key={s} className="opt" aria-pressed={slots.includes(s)} onClick={() => toggle(slots, setSlots, s)}>{s}</button>)}
          </div></div>
          <div className="grp"><h3>Days</h3><div className="opts">
            {DAYS.map((d) => <button key={d} className="opt" aria-pressed={days.includes(d)} onClick={() => toggle(days, setDays, d)}>{d}</button>)}
          </div></div>
          <div className="grp"><h3>Start</h3><div className="opts">
            {['Tomorrow', 'Next Monday'].map((s) => <button key={s} className="opt" aria-pressed={start === s} onClick={() => setStart(s)}>{s}</button>)}
          </div></div>
          <div className="total"><span>Per week</span><b>{valid ? inr(weekly) : '—'}</b></div>
          <button className="cta" disabled={!valid} onClick={() => setStep('confirm')}>Review order</button>
        </>
      ) : (
        <>
          <dl className="sum">
            <div><dt>Kitchen</dt><dd>{p.name}</dd></div>
            <div><dt>Meals</dt><dd>{slots.join(' + ')}</dd></div>
            <div><dt>Days</dt><dd>{days.join(', ')}</dd></div>
            <div><dt>Starts</dt><dd>{start}</dd></div>
            <div><dt>Weekly total</dt><dd><b>{inr(weekly)}</b></dd></div>
          </dl>
          <p className="mute small">Pay weekly by UPI. Skip a day before the cutoff and it’s credited to your next week. Demo only, no real payment.</p>
          <button className="cta" onClick={() => onDone({ p, slots, days, start, weekly })}>Pay {inr(weekly)} with UPI</button>
        </>
      )}
    </section>
  );
}
