import { useState } from 'react';
import { Check } from 'lucide-react';
import { inr } from '../data/providers';

const STEPS = ['Preparing', 'Out for delivery', 'Delivered'];

export default function Today({ order, onFind }) {
  const [skipped, setSkipped] = useState(false);
  if (!order) {
    return (
      <section className="page">
        <h1 className="title">Today</h1>
        <div className="empty"><h2>No active tiffin.</h2><p>Choose a kitchen and your plan shows up here.</p>
          <button className="cta" onClick={onFind}>Find a tiffin</button></div>
      </section>
    );
  }
  const { p, slots, weekly } = order;
  const credit = p.perMeal * slots.length;
  const date = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <section className="page">
      <p className="step">{date}</p>
      <h1 className="title">Lunch is on its way</h1>
      <p className="menu">{p.menu.Lunch}</p>
      <p className="mute small">{p.name} · arriving around 12:40 pm (demo)</p>

      <ol className="track" aria-label="Delivery status">
        {STEPS.map((s, i) => (
          <li key={s} className={i <= 1 ? 'done' : ''} aria-current={i === 1 ? 'step' : undefined}>
            <span className="node">{i < 1 && <Check size={12} />}</span>{s}
          </li>
        ))}
      </ol>

      <h3>Tomorrow</h3>
      <div className="skip">
        <p>{skipped ? `Skipped. ${inr(credit)} is credited to next week.` : 'Not home tomorrow? Skip it in one tap.'}</p>
        <button className="opt" aria-pressed={skipped} onClick={() => setSkipped(!skipped)}>{skipped ? 'Undo skip' : 'Skip tomorrow'}</button>
      </div>
      <p className="mute small">Plan: {inr(weekly)} per week</p>
    </section>
  );
}
