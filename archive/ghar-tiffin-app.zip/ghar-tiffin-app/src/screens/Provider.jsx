import { ArrowLeft } from 'lucide-react';
import { SLOTS, inr } from '../data/providers';

export default function Provider({ p, onBack, onNext }) {
  return (
    <section className="page">
      <button className="back" onClick={onBack}><ArrowLeft size={20} /> Back</button>
      <p className="step">Step 1 of 3 · Choose</p>
      <h1 className="title">{p.name}</h1>
      <p className="mute">{p.area} · {p.diets.join(', ')} · {inr(p.perMeal)} per meal</p>
      <h3>Today’s menu</h3>
      {SLOTS.map((s) => (
        <div className="menurow" key={s}><span>{s}</span><p>{p.menu[s]}</p></div>
      ))}
      <p className="mute small">Order before {p.cutoff} for same-day lunch. Skip any day from the Today tab.</p>
      <button className="cta" onClick={onNext}>Plan my tiffin</button>
    </section>
  );
}
