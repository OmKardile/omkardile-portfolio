# Changelog

## 0.1.0
- Discover: area select, diet filters, kitchen list with menu, price and cutoff
- Three-step order flow: choose, plan (meals, days, start, live weekly price), confirm (UPI mock)
- Today: delivery tracker and skip-tomorrow with credit note
- Terracotta accent on warm paper, Fraunces + Hanken Grotesk
